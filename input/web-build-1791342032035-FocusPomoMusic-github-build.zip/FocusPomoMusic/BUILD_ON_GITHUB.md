# Build FocusPomo Music as an APK

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

The workflow installs JDK 21, Android SDK API 36/build-tools 36.0.0, Gradle 9.5.0, runs `assembleDebug`, and uploads the generated APK as a workflow artifact.

The current container used to prepare this project does not include an Android SDK or a working Gradle installation, so the APK must be compiled in a real Android build environment (for example GitHub Actions or Android Studio).

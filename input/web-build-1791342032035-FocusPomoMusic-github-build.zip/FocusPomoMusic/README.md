# FocusPomo Music

Android native starter implementation based on the supplied specification:
- Kotlin + Jetpack Compose Material 3
- MVVM-style ViewModel state
- Pomodoro + Stopwatch + laps
- Foreground timer service + notifications
- Built-in audio preset
- Local audio file picker using Storage Access Framework
- YouTube embedded player
- Bottom mini-player

## Build
Open the project in Android Studio and let Gradle sync. The project targets compileSdk 36 and uses current dependencies selected for the 2026 toolchain.

## Notes
The supplied prompt requests `READ_EXTERNAL_STORAGE` / `READ_MEDIA_AUDIO`. The implementation declares them, but local file imports use the Storage Access Framework picker, which is the safer modern path and does not need broad storage access for user-selected files.

The supplied prompt mentions YouTube playlists. The library supports playlist initialization through `IFramePlayerOptions`; the first-pass UI currently loads individual video URLs and leaves the playlist hook documented in the code/UI for the next refinement.

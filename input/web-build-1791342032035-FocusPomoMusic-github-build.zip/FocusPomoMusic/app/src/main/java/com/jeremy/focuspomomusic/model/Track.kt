package com.jeremy.focuspomomusic.model

import android.net.Uri

data class Track(
    val id: String,
    val title: String,
    val subtitle: String,
    val uri: Uri,
    val isBuiltIn: Boolean
)

package com.jeremy.focuspomomusic.timer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Lap(val index: Int, val elapsedMs: Long)

class StopwatchEngine {
    private val _elapsedMs = MutableStateFlow(0L)
    val elapsedMs: StateFlow<Long> = _elapsedMs.asStateFlow()
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    private val _laps = MutableStateFlow<List<Lap>>(emptyList())
    val laps: StateFlow<List<Lap>> = _laps.asStateFlow()

    fun start() { _running.value = true }
    fun pause() { _running.value = false }
    fun reset() { _running.value = false; _elapsedMs.value = 0L; _laps.value = emptyList() }
    fun tick(deltaMs: Long) { if (_running.value) _elapsedMs.value += deltaMs }
    fun lap() {
        if (_running.value) _laps.value = _laps.value + Lap(_laps.value.size + 1, _elapsedMs.value)
    }
}

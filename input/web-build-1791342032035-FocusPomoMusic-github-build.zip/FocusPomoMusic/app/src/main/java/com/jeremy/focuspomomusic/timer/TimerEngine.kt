package com.jeremy.focuspomomusic.timer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TimerEngine {
    enum class Mode { WORK, SHORT_BREAK, LONG_BREAK }
    enum class State { IDLE, RUNNING, PAUSED }

    private val _remainingMs = MutableStateFlow(DEFAULT_WORK)
    val remainingMs: StateFlow<Long> = _remainingMs.asStateFlow()

    private val _mode = MutableStateFlow(Mode.WORK)
    val mode: StateFlow<Mode> = _mode.asStateFlow()

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    private var workMs = DEFAULT_WORK
    private var shortBreakMs = DEFAULT_SHORT
    private var longBreakMs = DEFAULT_LONG

    fun setDurations(work: Long, shortBreak: Long, longBreak: Long) {
        workMs = work.coerceAtLeast(1_000L)
        shortBreakMs = shortBreak.coerceAtLeast(1_000L)
        longBreakMs = longBreak.coerceAtLeast(1_000L)
        reset()
    }

    fun setRemaining(ms: Long) { _remainingMs.value = ms.coerceAtLeast(0L) }
    fun start() { _state.value = State.RUNNING }
    fun pause() { _state.value = State.PAUSED }
    fun reset() { _remainingMs.value = durationFor(_mode.value); _state.value = State.IDLE }

    fun skip() {
        _mode.value = when (_mode.value) {
            Mode.WORK -> Mode.SHORT_BREAK
            Mode.SHORT_BREAK -> Mode.WORK
            Mode.LONG_BREAK -> Mode.WORK
        }
        _remainingMs.value = durationFor(_mode.value)
        _state.value = State.IDLE
    }

    fun tick(deltaMs: Long): Boolean {
        val next = (_remainingMs.value - deltaMs).coerceAtLeast(0L)
        _remainingMs.value = next
        if (next == 0L) {
            _state.value = State.IDLE
            return true
        }
        return false
    }

    private fun durationFor(mode: Mode): Long = when (mode) {
        Mode.WORK -> workMs
        Mode.SHORT_BREAK -> shortBreakMs
        Mode.LONG_BREAK -> longBreakMs
    }

    companion object {
        const val DEFAULT_WORK = 25 * 60 * 1000L
        const val DEFAULT_SHORT = 5 * 60 * 1000L
        const val DEFAULT_LONG = 15 * 60 * 1000L
    }
}

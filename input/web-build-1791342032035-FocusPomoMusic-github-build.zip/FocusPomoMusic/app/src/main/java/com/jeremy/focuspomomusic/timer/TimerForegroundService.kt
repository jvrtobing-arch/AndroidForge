package com.jeremy.focuspomomusic.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class TimerForegroundService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var job: Job? = null
    private var remaining = TimerEngine.DEFAULT_WORK

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                remaining = intent.getLongExtra(EXTRA_REMAINING, TimerEngine.DEFAULT_WORK)
                startForeground(NOTIFICATION_ID, notification())
                startLoop()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startLoop() {
        job?.cancel()
        job = scope.launch {
            while (remaining > 0) {
                delay(1000)
                remaining = (remaining - 1000).coerceAtLeast(0)
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, notification())
            }
            managerNotifyFinished()
            stopSelf()
        }
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(getString(com.jeremy.focuspomomusic.R.string.app_name))
        .setContentText(format(remaining))
        .setOngoing(remaining > 0)
        .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    private fun managerNotifyFinished() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(
            NOTIFICATION_ID + 1,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(getString(com.jeremy.focuspomomusic.R.string.timer_finished))
                .setContentText("Waktu selesai. Saatnya berpindah sesi.")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
        )
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(com.jeremy.focuspomomusic.R.string.timer_channel_name), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun format(ms: Long): String {
        val total = ms / 1000
        return "%02d:%02d".format(total / 60, total % 60)
    }

    companion object {
        const val ACTION_START = "START"
        const val ACTION_STOP = "STOP"
        const val EXTRA_REMAINING = "remaining"
        const val CHANNEL_ID = "timer"
        const val NOTIFICATION_ID = 700
    }
}

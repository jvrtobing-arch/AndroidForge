package com.jeremy.focuspomomusic.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.key
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusPomoApp(vm: FocusPomoViewModel = viewModel()) {
    var selected by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    val currentTrack by vm.currentTrack.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FocusPomo Music") },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, contentDescription = "Settings") } }
            )
        },
        bottomBar = {
            Column(modifier = Modifier.navigationBarsPadding()) {
                currentTrack?.let { MiniPlayer(it.title, vm::toggleMusic) }
                NavigationBar {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Timer") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.PlayArrow, null) }, label = { Text("Music Center") })
                }
            }
        }
    ) { padding ->
        when (selected) {
            0 -> TimerScreen(vm, Modifier.padding(padding))
            1 -> MusicCenterScreen(vm, Modifier.padding(padding))
        }
    }

    if (showSettings) {
        TimerSettingsDialog(
            onDismiss = { showSettings = false },
            onApply = { work, shortBreak, longBreak ->
                vm.timer.setDurations(work * 60_000L, shortBreak * 60_000L, longBreak * 60_000L)
                showSettings = false
            }
        )
    }
}

@Composable
private fun TimerScreen(vm: FocusPomoViewModel, modifier: Modifier) {
    val remaining by vm.timer.remainingMs.collectAsState()
    val mode by vm.timer.mode.collectAsState()
    val state by vm.timer.state.collectAsState()
    val stopwatch by vm.stopwatch.elapsedMs.collectAsState()
    val laps by vm.stopwatch.laps.collectAsState()
    var stopwatchMode by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        TabRow(selectedTabIndex = if (stopwatchMode) 1 else 0) {
            Tab(!stopwatchMode, { stopwatchMode = false }, text = { Text("Pomodoro") })
            Tab(stopwatchMode, { stopwatchMode = true }, text = { Text("Stopwatch") })
        }
        Spacer(Modifier.height(24.dp))
        if (!stopwatchMode) {
            Text(mode.name.replace('_', ' '), style = MaterialTheme.typography.titleMedium)
            Text(formatDuration(remaining), style = MaterialTheme.typography.displayLarge)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (state == com.jeremy.focuspomomusic.timer.TimerEngine.State.RUNNING) vm.pausePomodoro() else vm.startPomodoro() }) {
                    Icon(if (state == com.jeremy.focuspomomusic.timer.TimerEngine.State.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                    Text(if (state == com.jeremy.focuspomomusic.timer.TimerEngine.State.RUNNING) "Pause" else "Start")
                }
                IconButton(onClick = vm::resetPomodoro) { Icon(Icons.Default.Refresh, "Reset") }
                IconButton(onClick = vm::skipPomodoro) { Icon(Icons.Default.SkipNext, "Skip") }
            }
            Spacer(Modifier.height(24.dp))
            Text("Sinkronisasi musik: gunakan Mini-Player untuk memilih audio preset/lokal.")
        } else {
            Text(formatDuration(stopwatch), style = MaterialTheme.typography.displayLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (vm.stopwatch.running.value) vm.stopwatch.pause() else vm.stopwatch.start() }) {
                    Text(if (vm.stopwatch.running.value) "Pause" else "Start")
                }
                Button(onClick = vm.stopwatch::lap) { Text("Lap") }
                IconButton(onClick = vm.stopwatch::reset) { Icon(Icons.Default.Refresh, "Reset") }
            }
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(laps) { Text("Lap ${it.index}: ${formatDuration(it.elapsedMs)}", modifier = Modifier.padding(vertical = 6.dp)) }
            }
        }
    }
}

@Composable
private fun MusicCenterScreen(vm: FocusPomoViewModel, modifier: Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Preset") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Local Files") })
            Tab(tab == 2, { tab = 2 }, text = { Text("YouTube") })
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> TrackList(vm.builtInTracks, vm::play)
            1 -> LocalFilesTab(vm)
            2 -> YouTubeTab()
        }
    }
}

@Composable
private fun TrackList(tracks: List<com.jeremy.focuspomomusic.model.Track>, onPlay: (com.jeremy.focuspomomusic.model.Track) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tracks) { track ->
            Card(onClick = { onPlay(track) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, null)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(track.title, style = MaterialTheme.typography.titleMedium)
                        Text(track.subtitle, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun LocalFilesTab(vm: FocusPomoViewModel) {
    val context = LocalContext.current
    val tracks by vm.localTracks.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            vm.addLocalUris(uris)
            Toast.makeText(context, "${uris.size} file ditambahkan", Toast.LENGTH_SHORT).show()
        }
    }
    Column {
        Button(onClick = { picker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/aac", "audio/*")) }) {
            Icon(Icons.Default.Add, null)
            Text("Tambah file musik")
        }
        Spacer(Modifier.height(12.dp))
        TrackList(tracks, vm::play)
    }
}

@Composable
private fun YouTubeTab() {
    var url by remember { mutableStateOf("") }
    var target by remember { mutableStateOf<YoutubeTarget?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), label = { Text("YouTube URL") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { target = parseYoutubeTarget(url) }) { Text("Load") }
            Button(onClick = { url = ""; target = null }) { Icon(Icons.Default.Stop, null); Text("Clear") }
        }
        target?.let { YouTubePlayerComposable(it, Modifier.fillMaxWidth()) }
        Text("Mendukung URL video dan playlist YouTube.", style = MaterialTheme.typography.bodySmall)
    }
}

private sealed interface YoutubeTarget {
    data class Video(val id: String) : YoutubeTarget
    data class Playlist(val id: String) : YoutubeTarget
}

private fun parseYoutubeTarget(input: String): YoutubeTarget? {
    val text = input.trim()
    Regex("[?&]list=([A-Za-z0-9_-]+)").find(text)?.groupValues?.getOrNull(1)?.let {
        return YoutubeTarget.Playlist(it)
    }
    val id = extractVideoId(text) ?: return null
    return YoutubeTarget.Video(id)
}

@Composable
private fun YouTubePlayerComposable(target: YoutubeTarget, modifier: Modifier) {
    val lifecycleOwner = LocalLifecycleOwner.current
    key(target) {
        AndroidView(
            modifier = modifier.height(220.dp),
            factory = { context ->
                YouTubePlayerView(context).also { view ->
                    view.enableAutomaticInitialization = false
                    lifecycleOwner.lifecycle.addObserver(view)
                    val listener = object : AbstractYouTubePlayerListener() {
                        override fun onReady(player: YouTubePlayer) {
                            when (target) {
                                is YoutubeTarget.Video -> player.loadVideo(target.id, 0f)
                                is YoutubeTarget.Playlist -> Unit
                            }
                        }
                    }
                    when (target) {
                        is YoutubeTarget.Video -> {
                            view.initialize(listener, IFramePlayerOptions.Builder().controls(1).build())
                        }
                        is YoutubeTarget.Playlist -> {
                            val options = IFramePlayerOptions.Builder()
                                .controls(1)
                                .listType("playlist")
                                .list(target.id)
                                .autoplay(1)
                                .build()
                            view.initialize(listener, options)
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun MiniPlayer(title: String, onToggle: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f))
            IconButton(onClick = onToggle) { Icon(Icons.Default.PlayArrow, "Play/Pause") }
        }
    }
}

@Composable
private fun TimerSettingsDialog(onDismiss: () -> Unit, onApply: (Long, Long, Long) -> Unit) {
    var work by remember { mutableStateOf("25") }
    var shortBreak by remember { mutableStateOf("5") }
    var longBreak by remember { mutableStateOf("15") }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("Timer settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                TextField(work, { work = it.filter(Char::isDigit) }, label = { Text("Work (menit)") }, singleLine = true)
                TextField(shortBreak, { shortBreak = it.filter(Char::isDigit) }, label = { Text("Short break (menit)") }, singleLine = true)
                TextField(longBreak, { longBreak = it.filter(Char::isDigit) }, label = { Text("Long break (menit)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                onApply(
                    work.toLongOrNull()?.coerceAtLeast(1) ?: 25,
                    shortBreak.toLongOrNull()?.coerceAtLeast(1) ?: 5,
                    longBreak.toLongOrNull()?.coerceAtLeast(1) ?: 15
                )
            }) { Text("Apply") }
        },
        dismissButton = { Button(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun formatDuration(ms: Long): String {
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms)
    return "%02d:%02d".format(seconds / 60, seconds % 60)
}

private fun extractVideoId(input: String): String? {
    val trimmed = input.trim()
    if (trimmed.length == 11 && !trimmed.contains('/')) return trimmed
    return Regex("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").find(trimmed)?.groupValues?.get(1)
}

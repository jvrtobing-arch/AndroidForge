package com.jeremy.focuspomomusic.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jeremy.focuspomomusic.R
import com.jeremy.focuspomomusic.media.MediaPlayerManager
import com.jeremy.focuspomomusic.model.Track
import com.jeremy.focuspomomusic.timer.StopwatchEngine
import com.jeremy.focuspomomusic.timer.TimerEngine
import com.jeremy.focuspomomusic.timer.TimerForegroundService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class FocusPomoViewModel(application: Application) : AndroidViewModel(application) {
    val timer = TimerEngine()
    val stopwatch = StopwatchEngine()
    private val media = MediaPlayerManager(application)

    private val _localTracks = MutableStateFlow<List<Track>>(emptyList())
    val localTracks: StateFlow<List<Track>> = _localTracks.asStateFlow()
    val builtInTracks = listOf(
        Track("preset-ambient", "Focus Ambient", "Built-in preset", uri = Uri.parse("android.resource://${application.packageName}/${R.raw.focus_ambient}"), isBuiltIn = true)
    )

    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    init {
        viewModelScope.launch {
            var previous = System.currentTimeMillis()
            while (isActive) {
                delay(100)
                val now = System.currentTimeMillis()
                val delta = now - previous
                previous = now
                if (timer.state.value == TimerEngine.State.RUNNING) {
                    val finished = timer.tick(delta)
                    if (finished) stopBackgroundTimer()
                }
                stopwatch.tick(delta)
            }
        }
    }

    fun addLocalUris(uris: List<Uri>) {
        val added = uris.mapIndexed { index, uri ->
            Track("local-${uri.hashCode()}-$index", uri.lastPathSegment ?: "Local audio", "Local file", uri, false)
        }
        _localTracks.value = (_localTracks.value + added).distinctBy { it.id }
    }

    fun play(track: Track) {
        media.play(track.uri)
        _currentTrack.value = track
    }

    fun toggleMusic() {
        if (media.player.isPlaying) media.pause() else media.resume()
    }

    fun startPomodoro() {
        timer.start()
        startBackgroundTimer()
    }

    fun pausePomodoro() {
        timer.pause()
        stopBackgroundTimer()
    }

    fun resetPomodoro() {
        timer.reset()
        stopBackgroundTimer()
    }

    fun skipPomodoro() {
        timer.skip()
    }

    private fun startBackgroundTimer() {
        val context = getApplication<Application>()
        val intent = Intent(context, TimerForegroundService::class.java).apply {
            action = TimerForegroundService.ACTION_START
            putExtra(TimerForegroundService.EXTRA_REMAINING, timer.remainingMs.value)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    private fun stopBackgroundTimer() {
        getApplication<Application>().stopService(Intent(getApplication(), TimerForegroundService::class.java))
    }

    override fun onCleared() {
        media.release()
        super.onCleared()
    }
}
